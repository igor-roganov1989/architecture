<?php
declare(strict_types=1);
namespace App\Domain\Model;

class LoanLead extends AbstractLead
{
    function getDescription(): string
    {
        // TODO: Implement getDescription() method.
    }
}