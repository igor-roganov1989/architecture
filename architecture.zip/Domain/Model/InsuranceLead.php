<?php
declare(strict_types=1);
namespace App\Domain\Model;

class InsuranceLead extends AbstractLead
{

    function getDescription(): string
    {
        // TODO: Implement getDescription() method.
    }
}